# AOK GRC MVP (FastAPI + SQLite)

## Run locally / Replit
1. Add a `.env` file (copy `.env.example`).
2. Install requirements.
3. Run:
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

Open:
- http://localhost:8000/docs

## Auth
- A seeded admin user is created on startup if none exists.
- Use /auth/token to login and get a Bearer token.

## Swap to Postgres later
Set:
DATABASE_URL=postgresql+psycopg2://user:pass@host:5432/dbname

Then add:
psycopg2-binary
and move to migrations (Alembic) instead of auto-create.
