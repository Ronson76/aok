from enum import Enum
from sqlalchemy import Integer, String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.db import Base


class UserRole(str, Enum):
    ADMIN = "Admin"
    SAFEGUARDING_LEAD = "SafeguardingLead"
    MANAGER = "Manager"
    VIEWER = "Viewer"
    STAFF = "Staff"
    RESIDENT = "Resident"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    org_id: Mapped[int | None] = mapped_column(ForeignKey("orgs.id"), nullable=True, index=True)
    service_id: Mapped[int | None] = mapped_column(ForeignKey("services.id"), nullable=True, index=True)

    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(200), nullable=True)
    role: Mapped[str] = mapped_column(String(50), default=UserRole.VIEWER.value, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="Active", nullable=False)

    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)

    org = relationship("Org", back_populates="users")
    service = relationship("Service", back_populates="users")
