from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    entity_type: Mapped[str] = mapped_column(String(30), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(64), nullable=False)
    event_type: Mapped[str] = mapped_column(String(40), nullable=False)
    actor_user_id: Mapped[str] = mapped_column(String(64), nullable=False)  # user id or "System"
    event_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=False)
    meta: Mapped[str | None] = mapped_column(String(500), nullable=True)
