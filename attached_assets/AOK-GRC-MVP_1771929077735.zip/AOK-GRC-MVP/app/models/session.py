from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class CheckInSession(Base):
    __tablename__ = "checkin_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    org_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)
    service_id: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)

    activity_type: Mapped[str] = mapped_column(String(80), nullable=False)
    scheduled_start_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=False)
    scheduled_end_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=False)
    grace_minutes: Mapped[int] = mapped_column(Integer, default=10, nullable=False)

    status: Mapped[str] = mapped_column(String(30), nullable=False)  # CompletedOnTime/CompletedLate/Missed/Cancelled
    completion_time_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=True)

    location_start: Mapped[str | None] = mapped_column(String(60), nullable=True)
    location_end: Mapped[str | None] = mapped_column(String(60), nullable=True)
