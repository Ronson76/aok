from sqlalchemy import DateTime, func
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class Timestamped(Base):
    __abstract__ = True
    created_utc: Mapped = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_utc: Mapped = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
