from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    session_id: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)

    org_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)
    service_id: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)

    alert_type: Mapped[str] = mapped_column(String(40), nullable=False)  # MissedCheckIn/Panic/Welfare/EscalationFailure
    severity: Mapped[str] = mapped_column(String(10), nullable=False)    # Low/Med/High
    triggered_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=False)

    current_state: Mapped[str] = mapped_column(String(20), default="Open", nullable=False)  # Open/InProgress/Resolved/Closed
    resolved_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=True)
    resolution_outcome: Mapped[str | None] = mapped_column(String(40), nullable=True)  # SafeConfirmed/FalseAlarm/EscalatedTo999/Other
