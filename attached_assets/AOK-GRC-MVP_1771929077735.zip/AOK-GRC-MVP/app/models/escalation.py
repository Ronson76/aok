from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class EscalationEvent(Base):
    __tablename__ = "escalation_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    alert_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)

    step_number: Mapped[int] = mapped_column(Integer, nullable=False)
    channel: Mapped[str] = mapped_column(String(10), nullable=False)  # SMS/Email/Call
    recipient_type: Mapped[str] = mapped_column(String(20), nullable=False)  # Contact/Team/Manager
    recipient_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    sent_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=False)
    delivered_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged_utc: Mapped = mapped_column(DateTime(timezone=True), nullable=True)

    result: Mapped[str] = mapped_column(String(20), nullable=False)  # Sent/Failed/Acknowledged/NoAnswer
