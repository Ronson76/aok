from enum import Enum


class Role(str, Enum):
    ADMIN = "Admin"
    SAFEGUARDING_LEAD = "SafeguardingLead"
    MANAGER = "Manager"
    VIEWER = "Viewer"
    STAFF = "Staff"
    RESIDENT = "Resident"


ROLE_ORDER = {
    Role.ADMIN: 100,
    Role.SAFEGUARDING_LEAD: 80,
    Role.MANAGER: 60,
    Role.VIEWER: 40,
    Role.STAFF: 20,
    Role.RESIDENT: 10,
}


def has_min_role(user_role: str, minimum: Role) -> bool:
    try:
        return ROLE_ORDER[Role(user_role)] >= ROLE_ORDER[minimum]
    except Exception:
        return False
