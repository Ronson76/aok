from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./aok.db"

    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 720

    seed_admin_email: str = "admin@aok.local"
    seed_admin_password: str = "ChangeThisPassword!"
    seed_admin_name: str = "AOK Admin"


settings = Settings()
