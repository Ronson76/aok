from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core.db import get_db
from app.schemas.service import ServiceCreate, ServiceOut
from app.models.service import Service
from app.routers.auth import get_current_user
from app.core.rbac import has_min_role, Role
from app.services.audit import write_audit

router = APIRouter(prefix="/services", tags=["services"])

@router.post("", response_model=ServiceOut)
def create_service(payload: ServiceCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.MANAGER):
        raise HTTPException(status_code=403, detail="Forbidden")
    s = Service(**payload.model_dump())
    db.add(s)
    write_audit(db, "Service", "new", "CreateService", str(me.id), meta=s.name)
    db.commit()
    db.refresh(s)
    return s

@router.get("", response_model=list[ServiceOut])
def list_services(org_id: int | None = None, db: Session = Depends(get_db), me=Depends(get_current_user)):
    q = select(Service)
    if org_id is not None:
        q = q.where(Service.org_id == org_id)
    return db.execute(q.order_by(Service.id.desc())).scalars().all()
