from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from sqlalchemy import select, func, and_
from datetime import datetime, timezone
import csv
import io

from app.core.db import get_db
from app.routers.auth import get_current_user
from app.core.rbac import has_min_role, Role
from app.models.session import CheckInSession
from app.models.alert import Alert
from app.models.escalation import EscalationEvent
from app.schemas.reports import KPIOut, ControlEffectivenessRow, GRCFeedRow
from app.services.scoring import rag, score_saf_01_checkin_compliance, score_saf_04_sla_within

router = APIRouter(prefix="/report", tags=["reports"])

def _parse_dt(s: str) -> datetime:
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

@router.get("/kpis", response_model=KPIOut)
def kpis(
    from_utc: str,
    to_utc: str,
    org_id: int | None = None,
    service_id: int | None = None,
    sla_minutes: int = 10,
    db: Session = Depends(get_db),
    me=Depends(get_current_user),
):
    if not has_min_role(me.role, Role.VIEWER):
        raise HTTPException(status_code=403, detail="Forbidden")

    start = _parse_dt(from_utc)
    end = _parse_dt(to_utc)

    s_filters = [CheckInSession.scheduled_end_utc >= start, CheckInSession.scheduled_end_utc < end]
    a_filters = [Alert.triggered_utc >= start, Alert.triggered_utc < end]
    if org_id is not None:
        s_filters.append(CheckInSession.org_id == org_id)
        a_filters.append(Alert.org_id == org_id)
    if service_id is not None:
        s_filters.append(CheckInSession.service_id == service_id)
        a_filters.append(Alert.service_id == service_id)

    total_sessions = db.execute(select(func.count()).select_from(CheckInSession).where(and_(*s_filters))).scalar() or 0
    completed_on_time = db.execute(
        select(func.count()).select_from(CheckInSession).where(and_(*s_filters, CheckInSession.status == "CompletedOnTime"))
    ).scalar() or 0
    missed = db.execute(
        select(func.count()).select_from(CheckInSession).where(and_(*s_filters, CheckInSession.status == "Missed"))
    ).scalar() or 0

    compliance_pct = (completed_on_time / total_sessions * 100.0) if total_sessions else 0.0
    missed_pct = (missed / total_sessions * 100.0) if total_sessions else 0.0

    total_alerts = db.execute(select(func.count()).select_from(Alert).where(and_(*a_filters))).scalar() or 0
    within = db.execute(
        select(func.count()).select_from(Alert).where(
            and_(*a_filters, Alert.resolved_utc.is_not(None),
                 (func.strftime('%s', Alert.resolved_utc) - func.strftime('%s', Alert.triggered_utc)) <= sla_minutes * 60)
        )
    ).scalar() or 0

    sla_within_pct = (within / total_alerts * 100.0) if total_alerts else 0.0

    sub = select(
        EscalationEvent.alert_id.label("aid"),
        func.min(EscalationEvent.acknowledged_utc).label("first_ack")
    ).where(EscalationEvent.acknowledged_utc.is_not(None)).group_by(EscalationEvent.alert_id).subquery()

    avg_ack = db.execute(
        select(func.avg(func.strftime('%s', sub.c.first_ack) - func.strftime('%s', Alert.triggered_utc)))
        .select_from(Alert)
        .join(sub, sub.c.aid == Alert.id)
        .where(and_(*a_filters))
    ).scalar()
    avg_ack = float(avg_ack) if avg_ack is not None else None

    avg_res = db.execute(
        select(func.avg(func.strftime('%s', Alert.resolved_utc) - func.strftime('%s', Alert.triggered_utc)))
        .select_from(Alert)
        .where(and_(*a_filters, Alert.resolved_utc.is_not(None)))
    ).scalar()
    avg_res = float(avg_res) if avg_res is not None else None

    open_high = db.execute(
        select(func.count()).select_from(Alert).where(and_(*a_filters, Alert.current_state.in_(["Open","InProgress"]), Alert.severity == "High"))
    ).scalar() or 0

    return KPIOut(
        org_id=org_id,
        service_id=service_id,
        period_start_utc=start.isoformat(),
        period_end_utc=end.isoformat(),
        checkin_compliance_pct=round(compliance_pct, 2),
        missed_checkin_rate_pct=round(missed_pct, 2),
        sla_within_pct=round(sla_within_pct, 2),
        avg_time_to_ack_seconds=avg_ack,
        avg_time_to_resolve_seconds=avg_res,
        open_high_risk_alerts=int(open_high),
    )

@router.get("/controls/effectiveness", response_model=list[ControlEffectivenessRow])
def controls_effectiveness(
    from_utc: str,
    to_utc: str,
    org_id: int | None = None,
    service_id: int | None = None,
    sla_minutes: int = 10,
    db: Session = Depends(get_db),
    me=Depends(get_current_user),
):
    if not has_min_role(me.role, Role.VIEWER):
        raise HTTPException(status_code=403, detail="Forbidden")

    kpi = kpis(from_utc, to_utc, org_id, service_id, sla_minutes, db, me)

    saf01 = score_saf_01_checkin_compliance(kpi.checkin_compliance_pct)
    saf04 = score_saf_04_sla_within(kpi.sla_within_pct)

    start = _parse_dt(from_utc)
    end = _parse_dt(to_utc)

    if kpi.missed_checkin_rate_pct > 0:
        missed_alerts = db.execute(
            select(func.count()).select_from(Alert).where(
                and_(Alert.triggered_utc >= start, Alert.triggered_utc < end,
                     *( [Alert.org_id == org_id] if org_id is not None else [] ),
                     *( [Alert.service_id == service_id] if service_id is not None else [] ),
                     Alert.alert_type == "MissedCheckIn")
            )
        ).scalar() or 0
        saf02 = 100.0 if missed_alerts > 0 else 40.0
    else:
        saf02 = 100.0

    rows = [
        ControlEffectivenessRow(
            org_id=org_id, service_id=service_id,
            control_id="AOK-SAF-01",
            effectiveness_score=round(saf01, 2),
            status=rag(saf01),
            exceptions_count=0,
            top_exception_reason=None,
        ),
        ControlEffectivenessRow(
            org_id=org_id, service_id=service_id,
            control_id="AOK-SAF-02",
            effectiveness_score=round(saf02, 2),
            status=rag(saf02),
            exceptions_count=0,
            top_exception_reason="No MissedCheckIn alerts logged" if saf02 < 80 else None,
        ),
        ControlEffectivenessRow(
            org_id=org_id, service_id=service_id,
            control_id="AOK-SAF-04",
            effectiveness_score=round(saf04, 2),
            status=rag(saf04),
            exceptions_count=0,
            top_exception_reason="Response SLA breaches" if saf04 < 90 else None,
        ),
    ]
    return rows

@router.get("/export/grc-feed.csv")
def grc_feed_csv(
    from_utc: str,
    to_utc: str,
    org_id: int | None = None,
    service_id: int | None = None,
    db: Session = Depends(get_db),
    me=Depends(get_current_user),
):
    if not has_min_role(me.role, Role.VIEWER):
        raise HTTPException(status_code=403, detail="Forbidden")

    rows = controls_effectiveness(from_utc, to_utc, org_id, service_id, 10, db, me)

    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["org_id","service_id","control_id","period_start_utc","period_end_utc","effectiveness_score","status","exceptions_count","top_exception_reason","evidence_link"])
    for r in rows:
        w.writerow([
            r.org_id, r.service_id, r.control_id, from_utc, to_utc,
            r.effectiveness_score, r.status, r.exceptions_count, r.top_exception_reason or "",
            f"/report/controls/effectiveness?from_utc={from_utc}&to_utc={to_utc}&org_id={org_id or ''}&service_id={service_id or ''}"
        ])

    return Response(content=out.getvalue(), media_type="text/csv")

@router.get("/export/grc-feed.json", response_model=list[GRCFeedRow])
def grc_feed_json(
    from_utc: str,
    to_utc: str,
    org_id: int | None = None,
    service_id: int | None = None,
    db: Session = Depends(get_db),
    me=Depends(get_current_user),
):
    if not has_min_role(me.role, Role.VIEWER):
        raise HTTPException(status_code=403, detail="Forbidden")

    rows = controls_effectiveness(from_utc, to_utc, org_id, service_id, 10, db, me)
    evidence = f"/report/controls/effectiveness?from_utc={from_utc}&to_utc={to_utc}&org_id={org_id or ''}&service_id={service_id or ''}"
    start = _parse_dt(from_utc).isoformat()
    end = _parse_dt(to_utc).isoformat()
    return [
        GRCFeedRow(
            org_id=r.org_id,
            service_id=r.service_id,
            control_id=r.control_id,
            period_start_utc=start,
            period_end_utc=end,
            effectiveness_score=r.effectiveness_score,
            status=r.status,
            exceptions_count=r.exceptions_count,
            top_exception_reason=r.top_exception_reason,
            evidence_link=evidence,
        )
        for r in rows
    ]
