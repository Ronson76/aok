from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.routers.auth import get_current_user
from app.core.rbac import has_min_role, Role
from app.schemas.session import CheckInSessionCreate, CheckInSessionOut
from app.schemas.alert import AlertCreate, AlertOut
from app.schemas.escalation import EscalationEventCreate, EscalationEventOut
from app.schemas.response_action import ResponseActionCreate, ResponseActionOut
from app.models.session import CheckInSession
from app.models.alert import Alert
from app.models.escalation import EscalationEvent
from app.models.response_action import ResponseAction
from app.services.audit import write_audit

router = APIRouter(prefix="/ingest", tags=["ingest"])

@router.post("/sessions", response_model=CheckInSessionOut)
def create_session(payload: CheckInSessionCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.STAFF):
        raise HTTPException(status_code=403, detail="Forbidden")
    s = CheckInSession(**payload.model_dump())
    db.add(s)
    write_audit(db, "CheckInSession", "new", "CreateSession", str(me.id))
    db.commit()
    db.refresh(s)
    return s

@router.post("/alerts", response_model=AlertOut)
def create_alert(payload: AlertCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.STAFF):
        raise HTTPException(status_code=403, detail="Forbidden")
    a = Alert(**payload.model_dump())
    db.add(a)
    write_audit(db, "Alert", "new", "CreateAlert", str(me.id), meta=a.alert_type)
    db.commit()
    db.refresh(a)
    return a

@router.post("/escalations", response_model=EscalationEventOut)
def create_escalation(payload: EscalationEventCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.STAFF):
        raise HTTPException(status_code=403, detail="Forbidden")
    e = EscalationEvent(**payload.model_dump())
    db.add(e)
    write_audit(db, "EscalationEvent", "new", "CreateEscalationEvent", str(me.id), meta=e.channel)
    db.commit()
    db.refresh(e)
    return e

@router.post("/actions", response_model=ResponseActionOut)
def create_action(payload: ResponseActionCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.STAFF):
        raise HTTPException(status_code=403, detail="Forbidden")
    ra = ResponseAction(**payload.model_dump())
    db.add(ra)
    write_audit(db, "ResponseAction", "new", "CreateResponseAction", str(me.id), meta=ra.action_type)
    db.commit()
    db.refresh(ra)
    return ra
