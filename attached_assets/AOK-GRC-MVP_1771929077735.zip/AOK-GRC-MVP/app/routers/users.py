from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core.db import get_db
from app.schemas.user import UserCreate, UserOut
from app.models.user import User
from app.routers.auth import get_current_user
from app.core.rbac import has_min_role, Role
from app.core.security import hash_password
from app.services.audit import write_audit

router = APIRouter(prefix="/users", tags=["users"])

@router.post("", response_model=UserOut)
def create_user(payload: UserCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.MANAGER):
        raise HTTPException(status_code=403, detail="Forbidden")
    if db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already exists")

    u = User(
        email=payload.email.lower(),
        full_name=payload.full_name,
        role=payload.role,
        status=payload.status,
        org_id=payload.org_id,
        service_id=payload.service_id,
        password_hash=hash_password(payload.password),
    )
    db.add(u)
    write_audit(db, "User", "new", "CreateUser", str(me.id), meta=u.email)
    db.commit()
    db.refresh(u)
    return u

@router.get("", response_model=list[UserOut])
def list_users(org_id: int | None = None, service_id: int | None = None, db: Session = Depends(get_db), me=Depends(get_current_user)):
    q = select(User)
    if org_id is not None:
        q = q.where(User.org_id == org_id)
    if service_id is not None:
        q = q.where(User.service_id == service_id)
    return db.execute(q.order_by(User.id.desc())).scalars().all()
