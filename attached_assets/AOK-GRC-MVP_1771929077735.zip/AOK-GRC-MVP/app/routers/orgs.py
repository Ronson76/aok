from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core.db import get_db
from app.schemas.org import OrgCreate, OrgOut
from app.models.org import Org
from app.routers.auth import get_current_user
from app.core.rbac import has_min_role, Role
from app.services.audit import write_audit

router = APIRouter(prefix="/orgs", tags=["orgs"])

@router.post("", response_model=OrgOut)
def create_org(payload: OrgCreate, db: Session = Depends(get_db), me=Depends(get_current_user)):
    if not has_min_role(me.role, Role.MANAGER):
        raise HTTPException(status_code=403, detail="Forbidden")
    o = Org(**payload.model_dump())
    db.add(o)
    write_audit(db, "Org", "new", "CreateOrg", str(me.id), meta=o.name)
    db.commit()
    db.refresh(o)
    return o

@router.get("", response_model=list[OrgOut])
def list_orgs(db: Session = Depends(get_db), me=Depends(get_current_user)):
    rows = db.execute(select(Org).order_by(Org.id.desc())).scalars().all()
    return rows
