from fastapi import FastAPI
from app.core.db import Base, engine, SessionLocal
from app.core.config import settings
from app.models import org, service, user, session, alert, escalation, response_action, audit  # noqa: F401
from app.routers import auth, orgs, services, users, ingest, reports
from app.core.security import hash_password

app = FastAPI(title="AOK GRC MVP", version="0.1.0")

# MVP: auto-create tables (production should use Alembic migrations)
Base.metadata.create_all(bind=engine)

app.include_router(auth.router)
app.include_router(orgs.router)
app.include_router(services.router)
app.include_router(users.router)
app.include_router(ingest.router)
app.include_router(reports.router)


@app.on_event("startup")
def seed_admin():
    """
    Create a first admin if the DB is empty. MVP convenience.
    """
    from sqlalchemy import select
    from app.models.user import User, UserRole

    db = SessionLocal()
    try:
        existing = db.execute(select(User).limit(1)).scalar_one_or_none()
        if existing:
            return

        admin = User(
            org_id=None,
            service_id=None,
            email=settings.seed_admin_email.lower(),
            full_name=settings.seed_admin_name,
            role=UserRole.ADMIN,
            status="Active",
            password_hash=hash_password(settings.seed_admin_password),
        )
        db.add(admin)
        db.commit()
    finally:
        db.close()
