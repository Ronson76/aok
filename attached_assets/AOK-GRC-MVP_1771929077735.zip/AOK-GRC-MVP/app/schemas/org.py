from pydantic import BaseModel

class OrgCreate(BaseModel):
    name: str
    org_type: str | None = None
    region: str | None = None

class OrgOut(OrgCreate):
    id: int
    class Config:
        from_attributes = True
