from pydantic import BaseModel

class KPIOut(BaseModel):
    org_id: int | None = None
    service_id: int | None = None
    period_start_utc: str
    period_end_utc: str

    checkin_compliance_pct: float
    missed_checkin_rate_pct: float
    sla_within_pct: float
    avg_time_to_ack_seconds: float | None
    avg_time_to_resolve_seconds: float | None
    open_high_risk_alerts: int

class ControlEffectivenessRow(BaseModel):
    org_id: int | None = None
    service_id: int | None = None
    control_id: str
    effectiveness_score: float
    status: str
    exceptions_count: int
    top_exception_reason: str | None = None

class GRCFeedRow(ControlEffectivenessRow):
    period_start_utc: str
    period_end_utc: str
    evidence_link: str
