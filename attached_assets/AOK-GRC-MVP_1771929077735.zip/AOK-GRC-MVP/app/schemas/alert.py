from pydantic import BaseModel
from datetime import datetime

class AlertCreate(BaseModel):
    session_id: int | None = None
    org_id: int
    service_id: int | None = None
    user_id: int
    alert_type: str
    severity: str
    triggered_utc: datetime
    current_state: str = "Open"
    resolved_utc: datetime | None = None
    resolution_outcome: str | None = None

class AlertOut(AlertCreate):
    id: int
    class Config:
        from_attributes = True
