from pydantic import BaseModel
from datetime import datetime

class ResponseActionCreate(BaseModel):
    alert_id: int
    performed_by_user_id: int
    action_type: str
    action_utc: datetime
    note: str | None = None

class ResponseActionOut(ResponseActionCreate):
    id: int
    class Config:
        from_attributes = True
