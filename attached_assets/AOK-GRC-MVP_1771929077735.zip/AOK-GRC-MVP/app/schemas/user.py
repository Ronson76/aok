from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email: EmailStr
    full_name: str | None = None
    role: str = "Viewer"
    status: str = "Active"
    password: str
    org_id: int | None = None
    service_id: int | None = None

class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str | None = None
    role: str
    status: str
    org_id: int | None = None
    service_id: int | None = None

    class Config:
        from_attributes = True
