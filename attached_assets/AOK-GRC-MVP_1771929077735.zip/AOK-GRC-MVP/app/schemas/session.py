from pydantic import BaseModel
from datetime import datetime

class CheckInSessionCreate(BaseModel):
    org_id: int
    service_id: int | None = None
    user_id: int
    activity_type: str
    scheduled_start_utc: datetime
    scheduled_end_utc: datetime
    grace_minutes: int = 10
    status: str
    completion_time_utc: datetime | None = None
    location_start: str | None = None
    location_end: str | None = None

class CheckInSessionOut(CheckInSessionCreate):
    id: int
    class Config:
        from_attributes = True
