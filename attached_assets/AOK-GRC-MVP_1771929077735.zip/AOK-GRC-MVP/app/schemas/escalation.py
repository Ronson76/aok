from pydantic import BaseModel
from datetime import datetime

class EscalationEventCreate(BaseModel):
    alert_id: int
    step_number: int
    channel: str
    recipient_type: str
    recipient_id: int | None = None
    sent_utc: datetime
    delivered_utc: datetime | None = None
    acknowledged_utc: datetime | None = None
    result: str

class EscalationEventOut(EscalationEventCreate):
    id: int
    class Config:
        from_attributes = True
