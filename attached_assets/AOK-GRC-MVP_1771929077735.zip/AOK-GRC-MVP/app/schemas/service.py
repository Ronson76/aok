from pydantic import BaseModel

class ServiceCreate(BaseModel):
    org_id: int
    name: str
    service_type: str | None = None
    manager_user_id: int | None = None

class ServiceOut(ServiceCreate):
    id: int
    class Config:
        from_attributes = True
