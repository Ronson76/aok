from dataclasses import dataclass

@dataclass(frozen=True)
class Thresholds:
    green: float
    amber: float

def rag(score: float, t: Thresholds = Thresholds(green=90.0, amber=80.0)) -> str:
    if score >= t.green:
        return "Green"
    if score >= t.amber:
        return "Amber"
    return "Red"

def clamp(x: float) -> float:
    return max(0.0, min(100.0, x))

def score_saf_01_checkin_compliance(compliance_pct: float) -> float:
    return clamp(compliance_pct)

def score_saf_02_detection_latency(avg_detection_seconds: float | None) -> float:
    if avg_detection_seconds is None:
        return 0.0
    if avg_detection_seconds <= 60:
        return 100.0
    if avg_detection_seconds >= 600:
        return 60.0
    return clamp(100.0 - (avg_detection_seconds - 60) * (40.0 / 540.0))

def score_saf_04_sla_within(sla_within_pct: float) -> float:
    return clamp(sla_within_pct)
