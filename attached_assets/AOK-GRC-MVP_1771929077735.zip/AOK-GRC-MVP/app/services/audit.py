from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.audit import AuditEvent

def write_audit(db: Session, entity_type: str, entity_id: str, event_type: str, actor_user_id: str, meta: str | None = None):
    evt = AuditEvent(
        entity_type=entity_type,
        entity_id=str(entity_id),
        event_type=event_type,
        actor_user_id=str(actor_user_id),
        event_utc=datetime.now(timezone.utc),
        meta=meta,
    )
    db.add(evt)
